#!/bin/bash

# Build the Docker image
docker build -t alice-biometrics_petisco:tests -f examples/envs/alice-biometrics_petisco__9abf7b1f6ef8c55bdddcb9a5c2eff513f6a93130/Dockerfile examples/repos/alice-biometrics_petisco__9abf7b1f6ef8c55bdddcb9a5c2eff513f6a93130

# Run tests (defaults to python -m pytest, will run unit tests and skip integration tests)
docker run --rm alice-biometrics_petisco:tests
